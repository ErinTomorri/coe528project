package coe528project;

/**
 * This class represents the Gold state of a customer.
 * It is part of the State Design Pattern.
 */
public class GoldState extends CustomerState {
    
    /**
     * Constructor for GoldState
     * @param customer The customer
     */
    public GoldState(Customer customer) {
        super(customer);
    }
    
    /**
     * Get the name of the state
     * @return The name of the state
     */
    @Override
    public String getStateName() {
        return "Gold";
    }
}