package coe528project;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

/**
 * This class represents a book selection with a checkbox.
 * It's used for the customer's book table view.
 */
public class BookSelection {
    private Book book;
    private BooleanProperty selected;
    
    /**
     * Constructor for BookSelection
     * @param book The book
     */
    public BookSelection(Book book) {
        this.book = book;
        this.selected = new SimpleBooleanProperty(false);
    }
    
    /**
     * Get the book
     * @return The book
     */
    public Book getBook() {
        return book;
    }
    
    /**
     * Set the book
     * @param book The book to set
     */
    public void setBook(Book book) {
        this.book = book;
    }
    
    /**
     * Check if the book is selected
     * @return True if the book is selected, false otherwise
     */
    public boolean isSelected() {
        return selected.get();
    }
    
    /**
     * Set whether the book is selected
     * @param selected Whether the book is selected
     */
    public void setSelected(boolean selected) {
        this.selected.set(selected);
    }
    
    /**
     * Get the selected property
     * @return The selected property
     */
    public BooleanProperty selectedProperty() {
        return selected;
    }
}