package coe528project;

import java.io.*;
import java.util.*;

/**
 * This class represents the BookStore.
 * It manages the books and customers.
 */
public class BookStore {
    private List<Book> books;
    private List<Customer> customers;
    private static BookStore instance = null;
    
    /**
     * Private constructor for BookStore (Singleton pattern)
     */
    private BookStore() {
        books = new ArrayList<>();
        customers = new ArrayList<>();
        loadData();
    }
    
    /**
     * Get the singleton instance of BookStore
     * @return The singleton instance of BookStore
     */
    public static BookStore getInstance() {
        if (instance == null) {
            instance = new BookStore();
        }
        return instance;
    }
    
    /**
     * Get the books in the store
     * @return The list of books
     */
    public List<Book> getBooks() {
        return books;
    }
    
    /**
     * Get the customers of the store
     * @return The list of customers
     */
    public List<Customer> getCustomers() {
        return customers;
    }
    
    /**
     * Add a book to the store
     * @param book The book to add
     */
    public void addBook(Book book) {
        books.add(book);
    }
    
    /**
     * Remove a book from the store
     * @param book The book to remove
     */
    public void removeBook(Book book) {
        books.remove(book);
    }
    
    /**
     * Add a customer to the store
     * @param customer The customer to add
     */
    public void addCustomer(Customer customer) {
        customers.add(customer);
    }
    
    /**
     * Remove a customer from the store
     * @param customer The customer to remove
     */
    public void removeCustomer(Customer customer) {
        customers.remove(customer);
    }
    
    /**
     * Find a customer by username
     * @param username The username to search for
     * @return The customer with the given username, or null if not found
     */
    public Customer findCustomer(String username, String password) {
        for (Customer c : customers) {
            if (c.getUsername().equals(username) && c.getPassword().equals(password)) {
                return c;
            }
        }
        return null;
    }
    
    /**
     * Check if a user can login
     * 
     * @param username The username to check
     * @param password The password to check
     * @return The Profile object if login successful, null otherwise
     */
    public Profile login(String username, String password) {
        // Check if it's the manager
        if (Manager.validate(username, password)) {
            return new Manager();
        }
        
        // Check if it's a customer
        Customer customer = findCustomer(username, password);
        if (customer != null) {
            return customer;
        }
        
        // Invalid credentials
        return null;
    }
    
    /**
     * Process a purchase
     * 
     * @param customer The customer making the purchase
     * @param selectedBooks The list of books being purchased
     * @param usePoints Whether to use points for discount
     * @return The final cost after discounts
     */
    public double processPurchase(Customer customer, List<Book> selectedBooks, boolean usePoints) {
        // Calculate total cost
        double totalCost = 0.0;
        for (Book book : selectedBooks) {
            totalCost += book.getPrice();
        }
        
        double finalCost = totalCost;
        
        // Apply points if requested
        if (usePoints && customer.getPoints() > 0) {
            finalCost = customer.redeemPoints(totalCost);
        }
        
        // Add points for this purchase (10 points per CAD)
        if (finalCost > 0) {
            int pointsEarned = (int) (finalCost * 10);
            customer.addPoints(pointsEarned);
        }
        
        return finalCost;
    }
    
    /**
     * Load data from files
     */
    public void loadData() {
        loadBooks();
        loadCustomers();
    }
    
    /**
     * Load books from file
     */
    private void loadBooks() {
        try (BufferedReader reader = new BufferedReader(new FileReader("books.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String name = parts[0];
                    double price = Double.parseDouble(parts[1]);
                    books.add(new Book(name, price));
                }
            }
        } catch (FileNotFoundException e) {
            // File doesn't exist yet, that's okay for a new system
        } catch (IOException e) {
            System.err.println("Error loading books: " + e.getMessage());
        }
    }
    
    /**
     * Load customers from file
     */
    private void loadCustomers() {
        try (BufferedReader reader = new BufferedReader(new FileReader("customers.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String username = parts[0];
                    String password = parts[1];
                    int points = Integer.parseInt(parts[2]);
                    customers.add(new Customer(username, password, points));
                }
            }
        } catch (FileNotFoundException e) {
            // File doesn't exist yet, that's okay for a new system
        } catch (IOException e) {
            System.err.println("Error loading customers: " + e.getMessage());
        }
    }
    
    /**
     * Save data to files
     */
    public void saveData() {
        saveBooks();
        saveCustomers();
    }
    
    /**
     * Save books to file
     */
    private void saveBooks() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("books.txt"))) {
            for (Book book : books) {
                writer.println(book.toString());
            }
        } catch (IOException e) {
            System.err.println("Error saving books: " + e.getMessage());
        }
    }
    
    /**
     * Save customers to file
     */
    private void saveCustomers() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("customers.txt"))) {
            for (Customer customer : customers) {
                writer.println(customer.toString());
            }
        } catch (IOException e) {
            System.err.println("Error saving customers: " + e.getMessage());
        }
    }
}