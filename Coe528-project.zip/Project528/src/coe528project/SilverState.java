package coe528project;

/**
 * This class represents the Silver state of a customer.
 * It is part of the State Design Pattern.
 */
public class SilverState extends CustomerState {
    
    /**
     * Constructor for SilverState
     * @param customer The customer
     */
    public SilverState(Customer customer) {
        super(customer);
    }
    
    /**
     * Get the name of the state
     * @return The name of the state
     */
    @Override
    public String getStateName() {
        return "Silver";
    }
}