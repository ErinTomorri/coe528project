package coe528project;

/**
 * This class represents a book in the bookstore.
 */
public class Book {
    private String name;
    private double price;
    
    /**
     * Constructor for Book
     * @param name The name of the book
     * @param price The price of the book
     */
    public Book(String name, double price) {
        this.name = name;
        this.price = price;
    }
    
    /**
     * Get the name of the book
     * @return The name of the book
     */
    public String getName() {
        return name;
    }
    
    /**
     * Set the name of the book
     * @param name The name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Get the price of the book
     * @return The price of the book
     */
    public double getPrice() {
        return price;
    }
    
    /**
     * Set the price of the book
     * @param price The price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }
    
    /**
     * String representation of a Book object
     * @return String representation of a Book
     */
    @Override
    public String toString() {
        return name + "," + price;
    }
}