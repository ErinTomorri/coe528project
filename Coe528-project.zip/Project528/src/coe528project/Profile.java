package coe528project;

/**
 * This class represents a user profile in the bookstore system.
 * It serves as a base class for Customer and is used for authentication.
 */
public class Profile {
    protected String username;
    protected String password;
    protected String role;
    
    /**
     * Default constructor for Profile
     */
    public Profile() {
        this.username = "";
        this.password = "";
        this.role = "";
    }
    
    /**
     * Constructor for Profile
     * @param username The username
     * @param password The password
     */
    public Profile(String username, String password) {
        this.username = username;
        this.password = password;
        setRole();
    }
    
    /**
     * Get the username
     * @return The username
     */
    public String getUsername() {
        return username;
    }
    
    /**
     * Set the username
     * @param username The username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }
    
    /**
     * Get the password
     * @return The password
     */
    public String getPassword() {
        return password;
    }
    
    /**
     * Set the password
     * @param password The password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
    
    /**
     * Get the role
     * @return The role
     */
    public String getRole() {
        return role;
    }
    
    /**
     * Set the role
     */
    public void setRole() {
        this.role = "User";
    }
    
    /**
     * Check if the profile is an admin/manager
     * @return True if the profile is an admin, false otherwise
     */
    public boolean isAdmin() {
        return "Admin".equals(role);
    }
    
    /**
     * Check if the profile is a customer
     * @return True if the profile is a customer, false otherwise
     */
    public boolean isCustomer() {
        return "Customer".equals(role);
    }
    
    /**
     * Convert the profile to a string for saving to file
     * @return String representation of the profile
     */
    @Override
    public String toString() {
        return username + "," + password;
    }
}