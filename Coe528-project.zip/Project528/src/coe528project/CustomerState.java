package coe528project;

/**
 * This abstract class represents the state of a customer.
 * It is part of the State Design Pattern.
 */
public abstract class CustomerState {
    protected Customer customer;
    
    /**
     * Constructor for CustomerState
     * @param customer The customer
     */
    public CustomerState(Customer customer) {
        this.customer = customer;
    }
    
    /**
     * Get the name of the state
     * @return The name of the state
     */
    public abstract String getStateName();
}