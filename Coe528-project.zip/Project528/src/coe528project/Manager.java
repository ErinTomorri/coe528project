package coe528project;

/**
 * This class represents the Manager/Admin of the bookstore.
 * It extends the Profile class.
 */
public class Manager extends Profile {
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin";
    
    /**
     * Constructor for Manager
     */
    public Manager() {
        super(ADMIN_USERNAME, ADMIN_PASSWORD);
    }
    
    /**
     * Set the role to "Admin"
     */
    @Override
    public void setRole() {
        super.role = "Admin";
    }
    
    /**
     * Validate if credentials match the admin credentials
     * @param username The username to check
     * @param password The password to check
     * @return True if credentials are valid for admin, false otherwise
     */
    public static boolean validate(String username, String password) {
        return ADMIN_USERNAME.equals(username) && ADMIN_PASSWORD.equals(password);
    }
}