package coe528project;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the BookStore Application.
 * It contains the GUI implementation.
 */
public class BookStoreApplication extends Application {
    private Stage primaryStage;
    private BookStore bookStore;
    private Profile currentUser;
    
    // TableViews
    private TableView<Book> bookTableView;
    private TableView<Customer> customerTableView;
    private TableView<BookSelection> customerBookTableView;
    
    // Observable lists
    private ObservableList<Book> bookObservableList;
    private ObservableList<Customer> customerObservableList;
    private ObservableList<BookSelection> customerBookObservableList;
    
    /**
     * The main entry point for all JavaFX applications.
     * @param primaryStage The primary stage for this application
     */
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.bookStore = BookStore.getInstance();
        this.currentUser = null;
        
        // Initialize observables
        bookObservableList = FXCollections.observableArrayList(bookStore.getBooks());
        customerObservableList = FXCollections.observableArrayList(bookStore.getCustomers());
        
        // Set up the primary stage
        primaryStage.setTitle("Book Store Application");
        primaryStage.setOnCloseRequest(this::handleExit);
        
        // Show the login screen
        showLoginScreen();
        
        primaryStage.show();
    }
    
    /**
     * Handle the exit event
     * @param event The exit event
     */
    private void handleExit(WindowEvent event) {
        bookStore.saveData();
        Platform.exit();
    }
    
    /**
     * Show the login screen
     */
    private void showLoginScreen() {
        // Create the grid pane
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        
        // Create the username label and field
        Label usernameLabel = new Label("Username:");
        grid.add(usernameLabel, 0, 0);
        TextField usernameField = new TextField();
        grid.add(usernameField, 1, 0);
        
        // Create the password label and field
        Label passwordLabel = new Label("Password:");
        grid.add(passwordLabel, 0, 1);
        PasswordField passwordField = new PasswordField();
        grid.add(passwordField, 1, 1);
        
        // Create the login button
        Button loginButton = new Button("Login");
        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().add(loginButton);
        grid.add(hbBtn, 1, 2);
        
        // Create the error label
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red;");
        grid.add(errorLabel, 1, 3);
        
        // Handle the login button action
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            
            currentUser = bookStore.login(username, password);
            
            if (currentUser != null) {
                if (currentUser.isAdmin()) {
                    showOwnerStartScreen();
                } else if (currentUser.isCustomer()) {
                    showCustomerStartScreen();
                }
            } else {
                errorLabel.setText("Invalid username or password");
            }
        });
        
        Scene scene = new Scene(grid, 400, 275);
        primaryStage.setScene(scene);
    }
    
    /**
     * Show the owner start screen
     */
    private void showOwnerStartScreen() {
        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(25, 25, 25, 25));
        
        Label welcomeLabel = new Label("Welcome Owner");
        welcomeLabel.setStyle("-fx-font-size: 20px;");
        
        Button booksButton = new Button("Books");
        booksButton.setPrefWidth(150);
        booksButton.setOnAction(e -> showOwnerBooksScreen());
        
        Button customersButton = new Button("Customers");
        customersButton.setPrefWidth(150);
        customersButton.setOnAction(e -> showOwnerCustomersScreen());
        
        Button logoutButton = new Button("Logout");
        logoutButton.setPrefWidth(150);
        logoutButton.setOnAction(e -> {
            currentUser = null;
            showLoginScreen();
        });
        
        vbox.getChildren().addAll(welcomeLabel, booksButton, customersButton, logoutButton);
        Scene scene = new Scene(vbox, 400, 300);
        primaryStage.setScene(scene);
    }
    
    /**
     * Show the owner books screen
     */
    private void showOwnerBooksScreen() {
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10, 10, 10, 10));
        
        // Top part - Table
        bookTableView = new TableView<>();
        bookObservableList = FXCollections.observableArrayList(bookStore.getBooks());
        
        TableColumn<Book, String> nameColumn = new TableColumn<>("Book Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameColumn.setPrefWidth(200);
        
        TableColumn<Book, Double> priceColumn = new TableColumn<>("Book Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceColumn.setPrefWidth(100);
        
        bookTableView.getColumns().addAll(nameColumn, priceColumn);
        bookTableView.setItems(bookObservableList);
        borderPane.setTop(bookTableView);
        
        // Middle part - Add form
        GridPane formGrid = new GridPane();
        formGrid.setAlignment(Pos.CENTER);
        formGrid.setHgap(10);
        formGrid.setVgap(10);
        formGrid.setPadding(new Insets(10, 10, 10, 10));
        
        Label nameLabel = new Label("Name:");
        formGrid.add(nameLabel, 0, 0);
        TextField nameField = new TextField();
        formGrid.add(nameField, 1, 0);
        
        Label priceLabel = new Label("Price:");
        formGrid.add(priceLabel, 0, 1);
        TextField priceField = new TextField();
        formGrid.add(priceField, 1, 1);
        
        Button addButton = new Button("Add");
        formGrid.add(addButton, 2, 0, 1, 2);
        
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red;");
        formGrid.add(errorLabel, 1, 2);
        
        addButton.setOnAction(e -> {
            try {
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());
                
                if (name.isEmpty()) {
                    errorLabel.setText("Name cannot be empty");
                    return;
                }
                
                // Check if book already exists
                for (Book book : bookStore.getBooks()) {
                    if (book.getName().equals(name)) {
                        errorLabel.setText("Book already exists");
                        return;
                    }
                }
                
                Book book = new Book(name, price);
                bookStore.addBook(book);
                bookObservableList.add(book);
                
                nameField.clear();
                priceField.clear();
                errorLabel.setText("");
            } catch (NumberFormatException ex) {
                errorLabel.setText("Invalid price");
            }
        });
        
        borderPane.setCenter(formGrid);
        
        // Bottom part - Buttons
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(10, 10, 10, 10));
        
        Button deleteButton = new Button("Delete");
        Button backButton = new Button("Back");
        
        deleteButton.setOnAction(e -> {
            Book selectedBook = bookTableView.getSelectionModel().getSelectedItem();
            if (selectedBook != null) {
                bookStore.removeBook(selectedBook);
                bookObservableList.remove(selectedBook);
            }
        });
        
        backButton.setOnAction(e -> showOwnerStartScreen());
        
        buttonBox.getChildren().addAll(deleteButton, backButton);
        borderPane.setBottom(buttonBox);
        
        Scene scene = new Scene(borderPane, 450, 400);
        primaryStage.setScene(scene);
    }
    
    /**
     * Show the owner customers screen
     */
    private void showOwnerCustomersScreen() {
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10, 10, 10, 10));
        
        // Top part - Table
        customerTableView = new TableView<>();
        customerObservableList = FXCollections.observableArrayList(bookStore.getCustomers());
        
        TableColumn<Customer, String> usernameColumn = new TableColumn<>("Username");
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        usernameColumn.setPrefWidth(150);
        
        TableColumn<Customer, String> passwordColumn = new TableColumn<>("Password");
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));
        passwordColumn.setPrefWidth(150);
        
        TableColumn<Customer, Integer> pointsColumn = new TableColumn<>("Points");
        pointsColumn.setCellValueFactory(new PropertyValueFactory<>("points"));
        pointsColumn.setPrefWidth(100);
        
        customerTableView.getColumns().addAll(usernameColumn, passwordColumn, pointsColumn);
        customerTableView.setItems(customerObservableList);
        borderPane.setTop(customerTableView);
        
        // Middle part - Add form
        GridPane formGrid = new GridPane();
        formGrid.setAlignment(Pos.CENTER);
        formGrid.setHgap(10);
        formGrid.setVgap(10);
        formGrid.setPadding(new Insets(10, 10, 10, 10));
        
        Label usernameLabel = new Label("Username:");
        formGrid.add(usernameLabel, 0, 0);
        TextField usernameField = new TextField();
        formGrid.add(usernameField, 1, 0);
        
        Label passwordLabel = new Label("Password:");
        formGrid.add(passwordLabel, 0, 1);
        TextField passwordField = new TextField();
        formGrid.add(passwordField, 1, 1);
        
        Button addButton = new Button("Add");
        formGrid.add(addButton, 2, 0, 1, 2);
        
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red;");
        formGrid.add(errorLabel, 1, 2);
        
        addButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            
            if (username.isEmpty() || password.isEmpty()) {
                errorLabel.setText("Username and password cannot be empty");
                return;
            }
            
            // Check if customer already exists
            for (Customer customer : bookStore.getCustomers()) {
                if (customer.getUsername().equals(username)) {
                    errorLabel.setText("Customer already exists");
                    return;
                }
            }
            
            Customer customer = new Customer(username, password);
            bookStore.addCustomer(customer);
            customerObservableList.add(customer);
            
            usernameField.clear();
            passwordField.clear();
            errorLabel.setText("");
        });
        
        borderPane.setCenter(formGrid);
        
        // Bottom part - Buttons
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(10, 10, 10, 10));
        
        Button deleteButton = new Button("Delete");
        Button backButton = new Button("Back");
        
        deleteButton.setOnAction(e -> {
            Customer selectedCustomer = customerTableView.getSelectionModel().getSelectedItem();
            if (selectedCustomer != null) {
                bookStore.removeCustomer(selectedCustomer);
                customerObservableList.remove(selectedCustomer);
            }
        });
        
        backButton.setOnAction(e -> showOwnerStartScreen());
        
        buttonBox.getChildren().addAll(deleteButton, backButton);
        borderPane.setBottom(buttonBox);
        
        Scene scene = new Scene(borderPane, 450, 400);
        primaryStage.setScene(scene);
    }
    
    /**
     * Show the customer start screen
     */
    private void showCustomerStartScreen() {
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10, 10, 10, 10));
        
        Customer customer = (Customer) currentUser;
        
        // Top part - Welcome message
        Label welcomeLabel = new Label("Welcome " + customer.getUsername() + 
                ". You have " + customer.getPoints() + " points. Your status is " + 
                customer.getStatus() + ".");
        welcomeLabel.setStyle("-fx-font-size: 14px;");
        borderPane.setTop(welcomeLabel);
        
        // Middle part - Book table with checkboxes
        customerBookTableView = new TableView<>();
        customerBookObservableList = FXCollections.observableArrayList();
        
        for (Book book : bookStore.getBooks()) {
            customerBookObservableList.add(new BookSelection(book));
        }
        
        TableColumn<BookSelection, String> nameColumn = new TableColumn<>("Book Name");
        nameColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().getBook().getName()));
        nameColumn.setPrefWidth(200);
        
        TableColumn<BookSelection, String> priceColumn = new TableColumn<>("Book Price");
        priceColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.format("%.2f", cellData.getValue().getBook().getPrice())));
        priceColumn.setPrefWidth(100);
        
        TableColumn<BookSelection, Boolean> selectColumn = new TableColumn<>("Select");
        selectColumn.setCellValueFactory(new PropertyValueFactory<>("selected"));
        selectColumn.setCellFactory(CheckBoxTableCell.forTableColumn(selectColumn));
        selectColumn.setPrefWidth(100);
        
        customerBookTableView.getColumns().addAll(nameColumn, priceColumn, selectColumn);
        customerBookTableView.setItems(customerBookObservableList);
        customerBookTableView.setEditable(true);
        borderPane.setCenter(customerBookTableView);
        
        // Bottom part - Buttons
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(10, 10, 10, 10));
        
        Button buyButton = new Button("Buy");
        Button redeemButton = new Button("Redeem points and Buy");
        Button logoutButton = new Button("Logout");
        
        buyButton.setOnAction(e -> {
            List<Book> selectedBooks = getSelectedBooks();
            if (selectedBooks.isEmpty()) {
                showAlert("No books selected", "Please select at least one book to buy.");
                return;
            }
            
            double totalCost = calculateTotalCost(selectedBooks);
            int pointsEarned = (int) (totalCost * 10); // 10 points per $1 spent
            
            customer.addPoints(pointsEarned);
            showCustomerCostScreen(selectedBooks, totalCost, false);
        });
        
        redeemButton.setOnAction(e -> {
            List<Book> selectedBooks = getSelectedBooks();
            if (selectedBooks.isEmpty()) {
                showAlert("No books selected", "Please select at least one book to buy.");
                return;
            }
            
            double totalCost = calculateTotalCost(selectedBooks);
            double discountAmount = customer.getPoints() / 100.0; // $1 per 100 points
            
            if (discountAmount > 0) {
                if (discountAmount >= totalCost) {
                    // Enough points to cover the entire purchase
                    int pointsRedeemed = (int) (totalCost * 100);
                    customer.redeemPoints(pointsRedeemed);
                    showCustomerCostScreen(selectedBooks, 0, true);
                } else {
                    // Partial discount
                    int pointsRedeemed = customer.getPoints();
                    customer.redeemPoints(pointsRedeemed);
                    showCustomerCostScreen(selectedBooks, totalCost - discountAmount, true);
                }
            } else {
                showAlert("No points to redeem", "You don't have any points to redeem.");
                int pointsEarned = (int) (totalCost * 10);
                customer.addPoints(pointsEarned);
                showCustomerCostScreen(selectedBooks, totalCost, true);
            }
        });
        
        logoutButton.setOnAction(e -> {
            currentUser = null;
            showLoginScreen();
        });
        
        buttonBox.getChildren().addAll(buyButton, redeemButton, logoutButton);
        borderPane.setBottom(buttonBox);
        
        Scene scene = new Scene(borderPane, 450, 400);
        primaryStage.setScene(scene);
    }
    
    /**
     * Show the customer cost screen
     * @param selectedBooks The list of selected books
     * @param totalCost The total cost of the purchase
     * @param redeemed Whether points were redeemed
     */
    private void showCustomerCostScreen(List<Book> selectedBooks, double totalCost, boolean redeemed) {
        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(25, 25, 25, 25));
        
        Customer customer = (Customer) currentUser;
        
        Label costLabel = new Label("Total Cost: $" + String.format("%.2f", totalCost));
        costLabel.setStyle("-fx-font-size: 16px;");
        
        Label pointsLabel = new Label("Points: " + customer.getPoints() + ", Status: " + 
                customer.getStatus());
        pointsLabel.setStyle("-fx-font-size: 14px;");
        
        Button logoutButton = new Button("Logout");
        logoutButton.setPrefWidth(150);
        logoutButton.setOnAction(e -> {
            currentUser = null;
            showLoginScreen();
        });
        
        vbox.getChildren().addAll(costLabel, pointsLabel, logoutButton);
        Scene scene = new Scene(vbox, 400, 300);
        primaryStage.setScene(scene);
    }
    
    /**
     * Get the list of selected books
     * @return The list of selected books
     */
    private List<Book> getSelectedBooks() {
        List<Book> selectedBooks = new ArrayList<>();
        for (BookSelection bookSelection : customerBookObservableList) {
            if (bookSelection.isSelected()) {
                selectedBooks.add(bookSelection.getBook());
            }
        }
        return selectedBooks;
    }
    
    /**
     * Calculate the total cost of the selected books
     * @param selectedBooks The list of selected books
     * @return The total cost
     */
    private double calculateTotalCost(List<Book> selectedBooks) {
        double totalCost = 0;
        for (Book book : selectedBooks) {
            totalCost += book.getPrice();
        }
        return totalCost;
    }
    
    /**
     * Show an alert dialog
     * @param title The title of the alert
     * @param message The message of the alert
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    /**
     * The main method
     * @param args The command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}